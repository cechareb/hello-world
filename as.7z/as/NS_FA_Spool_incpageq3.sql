SET heading off 
SET linesize 10000
SET pagesize 0 
SET newpage none 
SET feedback off 
SET termout off 
SET recsep off 
SET sqlprompt "" 
SET TRIMSPOOL ON 
SET echo off

spool 'V:\RA_Inteligencia_de_Procesos\39 Incidentes Pagos Facturacion Equipos\IncidentesMejora\NS_incidentespageqtrack.txt';
select x.codigoincidente||'|'||x.codigocompania||'|'||
e.compania||'|'||e.tipocuenta||'|'||e.codigocuentacompania||'|'||e.ciclofacturacion||'|'||
d.estadoincidente||'|'||d.tipoincidente||'|'||d.temaincidente||'|'||d.especificacionincidente||'|'||
SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(d.descripcionincidente,CHR(10),' ') ,CHR(13),' '),CHR(9),' '),CHR(124),' '),1,100)||'|'||
x.origen||'|'||x.destino||'|'||
x.fecha||'|'||d.fechaingresoincidente||'|'||to_char(fechaingresoincidente,'yyyymmdd hh24miss')||'|'||x.fecharecibido||'|'||to_char(fecharecibido,'yyyymmdd hh24miss')||'|'||
x.fechaaccion||'|'||to_char(fechaaccion,'yyyymmdd hh24miss')||'|'||d.fechacierreincidente||'|'||to_char(fechacierreincidente,'yyyymmdd hh24miss')||'|'||(round(x.fecharecibido-d.fechaingresoincidente,3)*24)||'|'||
(x.cuenta-1)||'|'||'-'||'|'||to_char(x.fecha,'yyyymm')||'|'||x.usuario from
(
select codigoincidente,codigocompania,fecha,origen,destino,fecharecibido,fechaaccion,usuario,cuenta from (
select codigoincidente,codigocompania,fecha,origen,destino,fecharecibido,fechaaccion,usuario,rn as cuenta from (
select a.codigoincidente,a.codigocompania,a.fecha,b.nombreinbox as origen,c.nombreinbox as destino,a.fecharecibido,a.fechaaccion,'-' as fechaenviado,a.usuariovantive as usuario,row_number () over (partition by a.codigoincidente order by a.fecharecibido asc) as rn
FROM DMARTSYS.TRACKINGINCIDENTES a 
left join DMARTSYS.INBOX b on a.codigoinboxorigen=b.codigoinbox
left join DMARTSYS.INBOX c on a.codigoinboxdestino=c.codigoinbox
order by fecha
)
) where codigoincidente in 
(
select distinct codigoincidente from (
select codigoincidente,codigocompania,fecha,origen,destino from (
select codigoincidente,codigocompania,fecha,origen,destino from (
select a.codigoincidente,a.codigocompania,a.fecha,b.nombreinbox as origen,c.nombreinbox as destino
FROM DMARTSYS.TRACKINGINCIDENTES a 
left join DMARTSYS.INBOX b on a.codigoinboxorigen=b.codigoinbox
left join DMARTSYS.INBOX c on a.codigoinboxdestino=c.codigoinbox
)
)
) where destino in ('FACT.EQUIPOS','FACT.PAGOS')
) order by codigoincidente, cuenta
) x
left join DMARTSYS.INCIDENTE d on x.codigoincidente=d.codigoincidente
left join DMARTSYS.COMPANIA e on x.codigocompania=e.codigocompania;


spool off;
exit;