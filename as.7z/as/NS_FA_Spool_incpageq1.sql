SET heading off 
SET linesize 10000
SET pagesize 0 
SET newpage none 
SET feedback off 
SET termout off 
SET recsep off 
SET sqlprompt "" 
SET TRIMSPOOL ON 
SET echo off

spool 'V:\RA_Inteligencia_de_Procesos\39 Incidentes Pagos Facturacion Equipos\IncidentesMejora\NS_incidentespageqent.txt';
select x.codigoincidente||'|'||x.codigocompania||'|'||
e.compania||'|'||e.tipocuenta||'|'||e.codigocuentacompania||'|'||e.ciclofacturacion||'|'||
d.estadoincidente||'|'||d.tipoincidente||'|'||d.temaincidente||'|'||d.especificacionincidente||'|'||
SUBSTR(REPLACE(REPLACE(REPLACE(REPLACE(d.descripcionincidente,CHR(10),' ') ,CHR(13),' '),CHR(9),' '),CHR(124),' '),1,100)||'|'||
x.origen||'|'||x.destino||'|'||
x.fecha||'|'||d.fechaingresoincidente||'|'||x.fecharecibido||'|'||x.fechaaccion||'|'||y.fecharecibido||'|'||d.fechacierreincidente||'|'||
round(y.fecharecibido-x.fecharecibido,3)*24||'|'||(round(x.fecharecibido-d.fechaingresoincidente,3)*24)||'|'||
(x.cuenta-1)||'|'||'-'||'|'||to_char(x.fecha,'yyyymm')||'|'||x.usuario
from (
select codigoincidente,codigocompania,fecha,origen,destino,fecharecibido,fechaaccion,usuario,cuenta from (
select codigoincidente,codigocompania,fecha,origen,destino,fecharecibido,fechaaccion,usuario,rn as cuenta from (
select a.codigoincidente,a.codigocompania,a.fecha,b.nombreinbox as origen,c.nombreinbox as destino,a.fecharecibido,a.fechaaccion,'-' as fechaenviado,a.usuariovantive as usuario,row_number () over (partition by a.codigoincidente order by a.fecharecibido asc) as rn
FROM DMARTSYS.TRACKINGINCIDENTES a 
left join DMARTSYS.INBOX b on a.codigoinboxorigen=b.codigoinbox
left join DMARTSYS.INBOX c on a.codigoinboxdestino=c.codigoinbox
order by fecha
)
)) x
left join
(select codigoincidente,fecharecibido,cuenta from (
select codigoincidente,fecharecibido,rn-1 as cuenta from (
select a.codigoincidente,a.fecharecibido,row_number () over (partition by a.codigoincidente order by a.fecharecibido asc) as rn
FROM DMARTSYS.TRACKINGINCIDENTES a 
order by fecha
)
)) y
on x.codigoincidente||x.cuenta=y.codigoincidente||y.cuenta
left join DMARTSYS.INCIDENTE d on x.codigoincidente=d.codigoincidente
left join DMARTSYS.COMPANIA e on x.codigocompania=e.codigocompania
where x.codigoincidente in (select m.codigoincidente
FROM DMARTSYS.TRACKINGINCIDENTES m
left join DMARTSYS.INBOX n 
on m.codigoinboxdestino=n.codigoinbox
where n.nombreinbox in ('FACT.EQUIPOS','FACT.PAGOS')
and m.fecha>=to_date('20160101','yyyymmdd')
)
and x.destino in ('FACT.EQUIPOS','FACT.PAGOS');


spool off;
exit;