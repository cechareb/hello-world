set timi on
truncate table FA_INCIDENTEDIARIO_PE_E;
truncate table FA_INCIDENTEDIARIO_PE_S;
exit